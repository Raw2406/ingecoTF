from __future__ import annotations

import hashlib
import os
from datetime import datetime
from typing import Any

import mysql.connector
from flask import Flask, jsonify, request, send_from_directory
# 1. Importa la extensión
from flask_cors import CORS


app = Flask(__name__, static_folder="frontend", static_url_path="")

CORS(app)
# Configuración de conexión a MySQL (puedes usar variables de entorno)
MYSQL_CONFIG = {
    "host": os.environ.get("MYSQL_HOST", "dayro-mysql-dayro-bb73.a.aivencloud.com"),
    "user": os.environ.get("MYSQL_USER", "avnadmin"),
    "password": os.environ.get("MYSQL_PASSWORD", "AVNS_-TRDZZ8YMHjk7_R1QIp"),
    "database": os.environ.get("MYSQL_DB", "autofinanzas"),
    "port": os.environ.get("MYSQL_PORT", 28080),
    "autocommit": True,
}

MARKET_DATA = {
    "BCP": (8.50, 15.00, 10.0, 20.0, 40.0, 50.0, 24, 36, 0, 3),
    "BBVA": (8.50, 15.00, 10.0, 10.0, 40.0, 50.0, 24, 36, 1, 2),
    "Interbank": (8.99, 16.00, 20.0, 20.0, 40.0, 40.0, 24, 36, 0, 2),
    "Scotiabank": (9.00, 16.50, 15.0, 20.0, 40.0, 40.0, 24, 36, 0, 2),
    "BanBif": (9.00, 15.00, 20.0, 20.0, 40.0, 40.0, 24, 36, 1, 1),
}


def get_connection():
    # Retorna una conexión con un cursor preparado para devolver diccionarios
    return mysql.connector.connect(**MYSQL_CONFIG)


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def split_name(full_name: str) -> tuple[str, str]:
    parts = [p for p in full_name.strip().split() if p]
    if not parts:
        return "", ""
    if len(parts) == 1:
        return parts[0], ""
    return " ".join(parts[:-1]), parts[-1]


def full_name(row: dict) -> str:
    return f"{row['nombre']} {row['apellido'] or ''}".strip()


def row_to_user(row: dict) -> dict[str, Any]:
    return {
        "id": row["id"],
        "idRol": row["id_rol"],
        "nombre": row["nombre"],
        "apellido": row["apellido"],
        "fullName": full_name(row),
        "email": row["email"],
    }


def init_db() -> None:
    # Creamos la base de datos si no existe (conector temporal sin DB especificada)
    temp_config = MYSQL_CONFIG.copy()
    db_name = temp_config.pop("database")
    try:
        conn_init = mysql.connector.connect(**temp_config)
        cursor_init = conn_init.cursor()
        cursor_init.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
        cursor_init.close()
        conn_init.close()
    except Exception as e:
        print(f"Advertencia al crear la base de datos: {e}")

    with get_connection() as conn:
        with conn.cursor() as cur:
            # Tabla 1: roles
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS roles (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    nombre VARCHAR(50) NOT NULL UNIQUE,
                    CONSTRAINT chk_rol_nombre CHECK (nombre IN ('admin', 'usuario'))
                )
                """
            )

            # Tabla 2: bancos
            cur.execute(
            """
                CREATE TABLE IF NOT EXISTS bancos (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    nombre VARCHAR(50) NOT NULL UNIQUE,
                    tea_min DECIMAL(10,6) NOT NULL,
                    tea_max DECIMAL(10,6) NOT NULL,
                    porcentaje_cuota_inicial_min DECIMAL(5,2) NOT NULL, -- Cambiado de (5,4) a (5,2)
                    porcentaje_cuota_inicial_max DECIMAL(5,2) NOT NULL, -- Cambiado de (5,4) a (5,2)
                    cuota_balon_final_min DECIMAL(5,2) NOT NULL,        -- Cambiado de (5,4) a (5,2)
                    cuota_balon_final_max DECIMAL(5,2) NOT NULL,        -- Cambiado de (5,4) a (5,2)
                    plazo_cuotas_min INT NOT NULL,
                    plazo_cuotas_max INT NOT NULL,
                    periodo_de_gracia_min INT NOT NULL,
                    periodo_de_gracia_max INT NOT NULL
                )
                """
            )

            # Tabla 3: usuarios
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS usuarios (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    id_rol INT NOT NULL,
                    nombre VARCHAR(100) NOT NULL,
                    apellido VARCHAR(100),
                    email VARCHAR(150) NOT NULL UNIQUE,
                    password VARCHAR(255) NOT NULL,
                    FOREIGN KEY(id_rol) REFERENCES roles(id)
                )
                """
            )

            # Tabla 4: simulaciones
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS simulaciones (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    id_usuario INT NOT NULL,
                    id_banco INT NOT NULL,
                    nombre_vehiculo VARCHAR(100) NOT NULL,
                    precio_vehiculo_usd DECIMAL(12,2) NOT NULL,
                    cuota_inicial_porc DECIMAL(5,2) NOT NULL,
                    monto_prestamo_usd DECIMAL(12,2) NOT NULL,
                    plazo_meses INT NOT NULL,
                    tea_aplicada_porc DECIMAL(10,6) NOT NULL,
                    tcea_calculado DECIMAL(10,6) NOT NULL,
                    tipo_gracia VARCHAR(20),
                    meses_gracia INT,
                    van DECIMAL(12,2),
                    tir DECIMAL(10,6),
                    cuota_balon DECIMAL(10,6),
                    estado VARCHAR(20) NOT NULL,
                    fecha_inicio DATE NOT NULL,
                    tem_aplicada DECIMAL(12,6),
                    desgravamen_incluido BOOLEAN,
                    seguro_vehicular_incluido BOOLEAN,
                    created_at VARCHAR(50) NOT NULL,
                    FOREIGN KEY(id_usuario) REFERENCES usuarios(id),
                    FOREIGN KEY(id_banco) REFERENCES bancos(id),
                    CONSTRAINT chk_estado CHECK (estado IN ('Guardado', 'Borrador'))
                )
                """
            )

            # Tabla 5: cronograma_pagos
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS cronograma_pagos (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    id_simulacion INT NOT NULL,
                    numero_cuota INT NOT NULL,
                    saldo_inicial DECIMAL(12,2),
                    interes DECIMAL(12,2),
                    cuota_mensual DECIMAL(12,2),
                    amortizacion DECIMAL(12,2),
                    seguro_desgravamen DECIMAL(12,2),
                    seguro_vehicular DECIMAL(12,2),
                    saldo_final DECIMAL(12,2),
                    fecha_pago DATE,
                    FOREIGN KEY(id_simulacion) REFERENCES simulaciones(id) ON DELETE CASCADE
                )
                """
            )

            # Datos base usando INSERT IGNORE equivalente en MySQL
            cur.execute("INSERT IGNORE INTO roles(nombre) VALUES ('admin')")
            cur.execute("INSERT IGNORE INTO roles(nombre) VALUES ('usuario')")

            for nombre, vals in MARKET_DATA.items():
                cur.execute(
                    """
                    INSERT IGNORE INTO bancos(
                        nombre, tea_min, tea_max, porcentaje_cuota_inicial_min,
                        porcentaje_cuota_inicial_max, cuota_balon_final_min,
                        cuota_balon_final_max, plazo_cuotas_min, plazo_cuotas_max,
                        periodo_de_gracia_min, periodo_de_gracia_max
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    (nombre, *vals),
                )

            cur.execute("SELECT id FROM roles WHERE nombre = 'usuario'")
            rol_usuario = cur.fetchone()[0]

            cur.execute("SELECT id FROM usuarios WHERE email = %s", ("demo@autofinanzas.pe",))
            exists = cur.fetchone()
            if not exists:
                cur.execute(
                    """
                    INSERT INTO usuarios(id_rol, nombre, apellido, email, password)
                    VALUES (%s, %s, %s, %s, %s)
                    """,
                    (rol_usuario, "Usuario", "Demo", "demo@autofinanzas.pe", hash_password("1234")),
                )


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/api/health")
def health():
    return jsonify({"ok": True, "database": MYSQL_CONFIG["database"], "schema": ["roles", "usuarios", "bancos", "simulaciones", "cronograma_pagos"]})


@app.get("/api/bancos")
def get_bancos():
    with get_connection() as conn:
        with conn.cursor(dictionary=True) as cur:
            cur.execute("SELECT * FROM bancos ORDER BY nombre")
            rows = cur.fetchall()
    return jsonify({"bancos": rows})


@app.post("/api/login")
def login():
    data = request.get_json(force=True)
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    with get_connection() as conn:
        with conn.cursor(dictionary=True) as cur:
            cur.execute(
                "SELECT * FROM usuarios WHERE lower(email) = %s AND password = %s",
                (email, hash_password(password)),
            )
            user = cur.fetchone()

    if not user:
        return jsonify({"error": "Correo o contraseña incorrectos."}), 401

    return jsonify({"user": row_to_user(user)})


@app.post("/api/register")
def register():
    data = request.get_json(force=True)

    full_name_value = data.get("fullName", "").strip()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not all([full_name_value, email, password]):
        return jsonify({"error": "Completa nombres, correo y contraseña."}), 400

    nombre, apellido = split_name(full_name_value)

    try:
        with get_connection() as conn:
            with conn.cursor(dictionary=True) as cur:
                cur.execute("SELECT id FROM roles WHERE nombre = 'usuario'")
                rol_usuario = cur.fetchone()["id"]
                
                cur.execute(
                    """
                    INSERT INTO usuarios(id_rol, nombre, apellido, email, password)
                    VALUES (%s, %s, %s, %s, %s)
                    """,
                    (rol_usuario, nombre, apellido, email, hash_password(password)),
                )
                user_id = cur.lastrowid
                
                cur.execute("SELECT * FROM usuarios WHERE id = %s", (user_id,))
                user = cur.fetchone()
    except mysql.connector.IntegrityError:
        return jsonify({"error": "Ya existe una cuenta con ese correo electrónico."}), 409

    return jsonify({"user": row_to_user(user)}), 201


@app.put("/api/users/<int:user_id>")
def update_user(user_id: int):
    data = request.get_json(force=True)

    full_name_value = data.get("fullName", "").strip()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not all([full_name_value, email]):
        return jsonify({"error": "Completa nombres y correo."}), 400

    nombre, apellido = split_name(full_name_value)

    try:
        with get_connection() as conn:
            with conn.cursor(dictionary=True) as cur:
                if password.strip():
                    cur.execute(
                        """
                        UPDATE usuarios
                        SET nombre = %s, apellido = %s, email = %s, password = %s
                        WHERE id = %s
                        """,
                        (nombre, apellido, email, hash_password(password), user_id),
                    )
                else:
                    cur.execute(
                        """
                        UPDATE usuarios
                        SET nombre = %s, apellido = %s, email = %s
                        WHERE id = %s
                        """,
                        (nombre, apellido, email, user_id),
                    )

                cur.execute("SELECT * FROM usuarios WHERE id = %s", (user_id,))
                user = cur.fetchone()
    except mysql.connector.IntegrityError:
        return jsonify({"error": "Ese correo ya está registrado en otra cuenta."}), 409

    if not user:
        return jsonify({"error": "Usuario no encontrado."}), 404

    return jsonify({"user": row_to_user(user)})


def build_plan_dict(conn, sim: dict) -> dict[str, Any]:
    with conn.cursor(dictionary=True) as cur:
        cur.execute("SELECT nombre FROM bancos WHERE id = %s", (sim["id_banco"],))
        banco_row = cur.fetchone()
        banco = banco_row["nombre"] if banco_row else "Banco"

        cur.execute(
            """
            SELECT * FROM cronograma_pagos
            WHERE id_simulacion = %s
            ORDER BY numero_cuota
            """,
            (sim["id"],),
        )
        rows = cur.fetchall()

    def format_date(value):
        if hasattr(value, "isoformat"):
            return value.isoformat()
        return str(value)

    schedule = []
    total_interest = 0.0
    total_payment = 0.0
    monthly_payment = 0.0

    meses_gracia = int(sim["meses_gracia"] or 0)
    plazo_meses = int(sim["plazo_meses"] or 0)
    tipo_gracia = sim["tipo_gracia"] or "Sin gracia"

    vehicle_price = float(sim["precio_vehiculo_usd"] or 0)
    balloon_pct = float(sim["cuota_balon"] or 0)
    balloon_amount = vehicle_price * balloon_pct / 100

    for row in rows:
        numero = int(row["numero_cuota"])

        if numero <= meses_gracia:
            tipo = f"Gracia {tipo_gracia}"
        elif numero == plazo_meses:
            tipo = "Cuota balón"
        else:
            tipo = "Cuota regular"

        cuota_total = float(row["cuota_mensual"] or 0)
        interest = float(row["interes"] or 0)
        sd = float(row["seguro_desgravamen"] or 0)
        veh = float(row["seguro_vehicular"] or 0)
        saldo_inicial = float(row["saldo_inicial"] or 0)
        saldo_final = float(row["saldo_final"] or 0)

        if tipo.startswith("Gracia Total"):
            cuota_financiera = 0.0
            amortizacion_regular = 0.0
            cuota_balon_pagada = 0.0

        elif tipo.startswith("Gracia Parcial"):
            cuota_financiera = interest
            amortizacion_regular = 0.0
            cuota_balon_pagada = 0.0

        elif tipo == "Cuota balón":
            # Última cuota bajo Compra Inteligente:
            # Pago total = cuota financiera + cuota balón + seguros.
            cuota_balon_pagada = balloon_amount

            cuota_financiera = max(
                cuota_total - sd - veh - cuota_balon_pagada,
                0.0,
            )

            amortizacion_regular = max(cuota_financiera - interest, 0.0)

            # Protección por redondeo: si por centavos no cuadra, ajustamos balón.
            if abs((cuota_financiera + cuota_balon_pagada + sd + veh) - cuota_total) > 0.05:
                cuota_balon_pagada = max(
                    cuota_total - sd - veh - cuota_financiera,
                    0.0,
                )

        else:
            # Cuota ordinaria:
            # Pago total = cuota financiera + seguros.
            cuota_financiera = max(cuota_total - sd - veh, 0.0)
            amortizacion_regular = max(cuota_financiera - interest, 0.0)
            cuota_balon_pagada = 0.0

        total_interest += interest
        total_payment += cuota_total

        if tipo == "Cuota regular" and monthly_payment == 0:
            monthly_payment = cuota_financiera

        schedule.append(
            {
                "cuota": numero,
                "fecha": format_date(row["fecha_pago"]),
                "saldoInicial": saldo_inicial,
                "interes": interest,
                "cuotaFinanciera": cuota_financiera,
                "amortizacion": amortizacion_regular,
                "seguroDesgravamen": sd,
                "seguroVehicular": veh,
                "cuotaBalonPagada": cuota_balon_pagada,
                "cuotaTotal": cuota_total,
                "saldoFinal": saldo_final,
                "tipo": tipo,
            }
        )

    if monthly_payment == 0:
        for row in schedule:
            if not str(row["tipo"]).startswith("Gracia"):
                monthly_payment = float(row["cuotaFinanciera"] or 0)
                break

    created_at = sim.get("created_at")
    fecha_inicio = sim.get("fecha_inicio")

    return {
        "id": sim["id"],
        "userId": sim["id_usuario"],
        "status": sim["estado"],
        "createdAt": format_date(created_at) if created_at else "",
        "name": f"Plan {banco} - USD {vehicle_price:,.0f}",
        "entity": banco,
        "vehiclePrice": vehicle_price,
        "initialPct": float(sim["cuota_inicial_porc"] or 0),
        "teaPct": float(sim["tea_aplicada_porc"] or 0),
        "temPct": float(sim["tem_aplicada"] or 0),
        "termMonths": plazo_meses,
        "graceMonths": meses_gracia,
        "graceType": tipo_gracia,
        "balloonPct": balloon_pct,
        "startDate": format_date(fecha_inicio) if fecha_inicio else "",
        "loanAmount": float(sim["monto_prestamo_usd"] or 0),
        "monthlyPayment": monthly_payment,
        "totalPayment": total_payment,
        "totalInterest": total_interest,
        "tceaPct": float(sim["tcea_calculado"] or 0),
        "van": float(sim["van"] or 0),
        "tirMonthlyPct": float(sim["tir"] or 0),
        "schedule": schedule,
    }

@app.get("/api/plans")
def get_plans():
    user_id = request.args.get("userId", type=int)
    if not user_id:
        return jsonify({"error": "Falta userId."}), 400

    with get_connection() as conn:
        with conn.cursor(dictionary=True) as cur:
            cur.execute(
                """
                SELECT * FROM simulaciones
                WHERE id_usuario = %s
                ORDER BY created_at DESC, id DESC
                """,
                (user_id,),
            )
            sims = cur.fetchall()

        plans = [build_plan_dict(conn, sim) for sim in sims]

    return jsonify({"plans": plans})


@app.post("/api/plans")
def create_plan():
    data = request.get_json(force=True)

    user_id = data.get("userId")
    status = data.get("status", "Guardado")
    summary = data.get("summary") or {}
    schedule = data.get("schedule") or []

    if not user_id or not summary or not schedule:
        return jsonify({"error": "Faltan datos del plan."}), 400

    with get_connection() as conn:
        with conn.cursor(dictionary=True) as cur:
            cur.execute("SELECT id FROM usuarios WHERE id = %s", (user_id,))
            user = cur.fetchone()
            if not user:
                return jsonify({"error": "Usuario no encontrado."}), 404

            cur.execute("SELECT id FROM bancos WHERE nombre = %s", (summary.get("entity"),))
            banco = cur.fetchone()
            if not banco:
                return jsonify({"error": "Banco no encontrado."}), 404

            desgravamen = any(float(r.get("seguroDesgravamen") or 0) > 0 for r in schedule)
            vehicular = any(float(r.get("seguroVehicular") or 0) > 0 for r in schedule)

            cur.execute(
                """
                INSERT INTO simulaciones(
                    id_usuario, id_banco, nombre_vehiculo, precio_vehiculo_usd,
                    cuota_inicial_porc, monto_prestamo_usd, plazo_meses,
                    tea_aplicada_porc, tcea_calculado, tipo_gracia,
                    meses_gracia, van, tir, cuota_balon, estado, fecha_inicio,
                    tem_aplicada, desgravamen_incluido, seguro_vehicular_incluido,
                    created_at
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    user_id,
                    banco["id"],
                    summary.get("name", "Vehículo"),
                    summary.get("vehiclePrice", 0),
                    summary.get("initialPct", 0),
                    summary.get("loanAmount", 0),
                    summary.get("termMonths", 0),
                    summary.get("teaPct", 0),
                    summary.get("tceaPct", 0),
                    summary.get("graceType", "Sin gracia"),
                    summary.get("graceMonths", 0),
                    summary.get("van", 0),
                    summary.get("tirMonthlyPct", 0),
                    summary.get("balloonPct", 0),
                    status,
                    summary.get("startDate"),
                    summary.get("temPct", 0),
                    1 if desgravamen else 0,
                    1 if vehicular else 0,
                    datetime.now().isoformat(timespec="seconds"),
                ),
            )
            sim_id = cur.lastrowid

            for row in schedule:
                cur.execute(
                    """
                    INSERT INTO cronograma_pagos(
                        id_simulacion, numero_cuota, saldo_inicial, interes,
                        cuota_mensual, amortizacion, seguro_desgravamen,
                        seguro_vehicular, saldo_final, fecha_pago
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        sim_id,
                        row.get("cuota"),
                        row.get("saldoInicial"),
                        row.get("interes"),
                        row.get("cuotaTotal"),
                        row.get("amortizacion"),
                        row.get("seguroDesgravamen"),
                        row.get("seguroVehicular"),
                        row.get("saldoFinal"),
                        row.get("fecha"),
                    ),
                )

            cur.execute("SELECT * FROM simulaciones WHERE id = %s", (sim_id,))
            sim = cur.fetchone()
            plan = build_plan_dict(conn, sim)

    return jsonify({"plan": plan}), 201

@app.put("/api/plans/<int:plan_id>")
def update_plan(plan_id: int):
    data = request.get_json(force=True)

    user_id = data.get("userId")
    status = data.get("status", "Guardado")
    summary = data.get("summary") or {}
    schedule = data.get("schedule") or []

    if not user_id or not summary or not schedule:
        return jsonify({"error": "Faltan datos del plan para actualizar."}), 400

    with get_connection() as conn:
        with conn.cursor(dictionary=True) as cur:
            cur.execute(
                "SELECT id FROM simulaciones WHERE id = %s AND id_usuario = %s",
                (plan_id, user_id),
            )
            existing = cur.fetchone()

            if not existing:
                return jsonify({"error": "Plan no encontrado o no pertenece al usuario."}), 404

            cur.execute(
                "SELECT id FROM bancos WHERE nombre = %s",
                (summary.get("entity"),),
            )
            banco = cur.fetchone()

            if not banco:
                return jsonify({"error": "Banco no encontrado."}), 404

            desgravamen = any(
                float(r.get("seguroDesgravamen") or 0) > 0 for r in schedule
            )
            vehicular = any(
                float(r.get("seguroVehicular") or 0) > 0 for r in schedule
            )

            cur.execute(
                """
                UPDATE simulaciones
                SET id_banco = %s,
                    nombre_vehiculo = %s,
                    precio_vehiculo_usd = %s,
                    cuota_inicial_porc = %s,
                    monto_prestamo_usd = %s,
                    plazo_meses = %s,
                    tea_aplicada_porc = %s,
                    tcea_calculado = %s,
                    tipo_gracia = %s,
                    meses_gracia = %s,
                    van = %s,
                    tir = %s,
                    cuota_balon = %s,
                    estado = %s,
                    fecha_inicio = %s,
                    tem_aplicada = %s,
                    desgravamen_incluido = %s,
                    seguro_vehicular_incluido = %s
                WHERE id = %s AND id_usuario = %s
                """,
                (
                    banco["id"],
                    summary.get("name", "Vehículo"),
                    summary.get("vehiclePrice", 0),
                    summary.get("initialPct", 0),
                    summary.get("loanAmount", 0),
                    summary.get("termMonths", 0),
                    summary.get("teaPct", 0),
                    summary.get("tceaPct", 0),
                    summary.get("graceType", "Sin gracia"),
                    summary.get("graceMonths", 0),
                    summary.get("van", 0),
                    summary.get("tirMonthlyPct", 0),
                    summary.get("balloonPct", 0),
                    status,
                    summary.get("startDate"),
                    summary.get("temPct", 0),
                    1 if desgravamen else 0,
                    1 if vehicular else 0,
                    plan_id,
                    user_id,
                ),
            )

            cur.execute(
                "DELETE FROM cronograma_pagos WHERE id_simulacion = %s",
                (plan_id,),
            )

            for row in schedule:
                cur.execute(
                    """
                    INSERT INTO cronograma_pagos(
                        id_simulacion,
                        numero_cuota,
                        saldo_inicial,
                        interes,
                        cuota_mensual,
                        amortizacion,
                        seguro_desgravamen,
                        seguro_vehicular,
                        saldo_final,
                        fecha_pago
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        plan_id,
                        row.get("cuota"),
                        row.get("saldoInicial"),
                        row.get("interes"),
                        row.get("cuotaTotal"),
                        row.get("amortizacion"),
                        row.get("seguroDesgravamen"),
                        row.get("seguroVehicular"),
                        row.get("saldoFinal"),
                        row.get("fecha"),
                    ),
                )

            cur.execute("SELECT * FROM simulaciones WHERE id = %s", (plan_id,))
            updated_sim = cur.fetchone()

            plan = build_plan_dict(conn, updated_sim)

        conn.commit()

    return jsonify({"plan": plan})

@app.delete("/api/plans/<int:plan_id>")
def delete_plan(plan_id: int):
    user_id = request.args.get("userId", type=int)
    if not user_id:
        return jsonify({"error": "Falta userId."}), 400

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM simulaciones WHERE id = %s AND id_usuario = %s", (plan_id, user_id))
            rowcount = cur.rowcount

    if rowcount == 0:
        return jsonify({"error": "Plan no encontrado."}), 404

    return jsonify({"ok": True})


if __name__ == "__main__":
    init_db()
    app.run(debug=True)